/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable @next/next/no-img-element */
import React from 'react'
import './Clients.css'

const Clients = () => {
    return (
        <div className='p-4 lg:p-24'>
            <div className="wrapper">
                <div className="item item1">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item2">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item3">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item4">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item5">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item6">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item7">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="item item8">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
            </div>

            <div className="wrapper">
                <div className="itemw item1">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item2">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item3">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item4">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item5">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item6">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item7">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
                <div className="itemw item8">
                    <img src='https://res.cloudinary.com/dpmum6s9p/image/upload/v1723220878/mindsale/mindsalewhite_1_kqrlqd.webp' />
                </div>
            </div>

        </div>
    )
}

export default Clients